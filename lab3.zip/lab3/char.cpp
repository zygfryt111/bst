#include<iostream>
#include<string>
using namespace std;



    
int main(void){
    int n;
    cout<<"Wprowadz n"<<endl;
    cin>>n;
    stringstream ss;
    ss << n;
    string str = ss.str();
    std::cout << SSTR( "i is: " << n );
    std::string n = SSTR( n );
    system("pause");
    return 0;
    }
